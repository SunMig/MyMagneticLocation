package com.example.lenovo.myhybridlocation.WifiThread;

/**
 * Created by Lenovo on 2018/11/3.
 */

public interface WifiLocationListener {
    public void onLocation(double x, double y, double weight);

}
