package com.example.lenovo.myhybridlocation.MainClass;

/**
 * Created by Lenovo on 2018/11/4.
 */

public interface HybridLocationListener {
    public void onLocation(double B, double L, String floor);
}
